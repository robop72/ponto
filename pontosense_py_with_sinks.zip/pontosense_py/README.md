# Pontosense Python Integration

FastAPI service that:
- Subscribes to **Events Notification API** via MQTT over TLS/X.509, using `/client/{clientId}`.
- Calls **System Management HTTP API** endpoints under `/tpi/v1/ps3` (firmware, sensors, zones, scan area, fall, location start/stop, upgrade).

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .
cp .env.example .env
# Edit .env with your Access Key and cert paths
uvicorn pontosense_py.app:app
```

- Browse events at `GET /events` (last N buffered).
- Health check `GET /health`.