from __future__ import annotations
import httpx
from .config import HTTP

class PsHttp:
    def __init__(self, timeout: float = 15.0):
        self._client = httpx.AsyncClient(
            base_url=HTTP.base_url, timeout=httpx.Timeout(timeout)
        )

    async def close(self):
        await self._client.aclose()

    async def get(self, path: str, params: dict | None = None):
        return await self._client.get(
            path, params=params, headers={HTTP.header_name: HTTP.access_key}
        )

    async def post(self, path: str, json: dict | None = None):
        return await self._client.post(
            path, json=json, headers={HTTP.header_name: HTTP.access_key}
        )

    async def put(self, path: str, json: dict | None = None):
        return await self._client.put(
            path, json=json, headers={HTTP.header_name: HTTP.access_key}
        )

    async def delete(self, path: str):
        return await self._client.delete(
            path, headers={HTTP.header_name: HTTP.access_key}
        )