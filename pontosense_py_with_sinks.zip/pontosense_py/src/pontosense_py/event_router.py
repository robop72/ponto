from __future__ import annotations
from typing import Callable
from .types import EventReport, LwtReport, Presence

EventHandler = Callable[..., None]

class Handlers:
    on_online: EventHandler | None = None
    on_lwt_offline: EventHandler | None = None
    on_presence: EventHandler | None = None
    on_fall: EventHandler | None = None
    on_pfall: EventHandler | None = None
    on_bedin: EventHandler | None = None
    on_couchin: EventHandler | None = None
    on_radar_error: EventHandler | None = None
    on_upgrade: EventHandler | None = None
    on_any: EventHandler | None = None

def route_event(raw: dict, h: Handlers):
    try:
        lw = LwtReport(**raw)
        if lw.method == "lwt.report":
            if h.on_lwt_offline: h.on_lwt_offline(lw.params.sn, lw.params.orgId)
            if h.on_any: h.on_any(raw)
            return
    except Exception:
        pass

    try:
        ev = EventReport(**raw)
        if ev.method != "event.report":
            if h.on_any: h.on_any(raw)
            return
        p = ev.params
        if p.online and h.on_online: h.on_online(p.sn, p.orgId)
        if p.presence:
            pr: Presence = p.presence
            if h.on_presence: h.on_presence(p.sn, p.orgId, pr.model_dump())
            if pr.fall and h.on_fall:
                h.on_fall(p.sn, p.orgId, [t.model_dump() for t in pr.fall])
            if pr.pfall and h.on_pfall:
                h.on_pfall(p.sn, p.orgId, [t.model_dump() for t in pr.pfall])
            if pr.bedin and h.on_bedin:
                h.on_bedin(p.sn, p.orgId, [t.model_dump() for t in pr.bedin])
            if pr.couchin and h.on_couchin:
                h.on_couchin(p.sn, p.orgId, [t.model_dump() for t in pr.couchin])
        if p.radar and p.radar.get("error", 0) != 0 and h.on_radar_error:
            h.on_radar_error(p.sn, p.orgId, int(p.radar["error"]))
        if p.upgrade and h.on_upgrade:
            h.on_upgrade(p.sn, p.orgId, p.upgrade.get("state"), p.upgrade.get("code"))
        if h.on_any: h.on_any(ev.model_dump())
    except Exception:
        if h.on_any: h.on_any(raw)