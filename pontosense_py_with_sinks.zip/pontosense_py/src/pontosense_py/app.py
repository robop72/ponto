from __future__ import annotations
import time
from typing import Deque, Tuple
from collections import deque
from fastapi import FastAPI, Query, Depends, Header, HTTPException
from fastapi.responses import ORJSONResponse
from .http_client import PsHttp
from .system import SystemApi
from .mqtt_client import start_mqtt_listener
from .event_router import Handlers
from .sinks import EventDispatcher
import os

def create_app() -> FastAPI:
    app = FastAPI(title="Pontosense Integration", default_response_class=ORJSONResponse)

    events: Deque[Tuple[float, dict]] = deque(maxlen=1000)

    # sinks
    dispatcher = EventDispatcher()

    http = PsHttp()
    sysapi = SystemApi(http)
    handlers = Handlers()

# ---- Simple API key auth ----
APP_API_KEY = os.getenv("APP_API_KEY") or ""
APP_AUTH_HEADER = os.getenv("APP_AUTH_HEADER") or "X-Internal-Auth"
def require_key(x_internal_auth: str | None = Header(default=None, alias=APP_AUTH_HEADER)):
    if not APP_API_KEY:
        return  # disabled
    if x_internal_auth != APP_API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")


    handlers.on_any = lambda msg: (events.append((time.time(), msg)), dispatcher.submit(msg))
    handlers.on_fall = lambda sn, org, targets: (events.append((time.time(), {"type":"fall","sn":sn,"orgId":org,"targets":targets})), dispatcher.submit({"type":"fall","sn":sn,"orgId":org,"targets":targets}))
    handlers.on_lwt_offline = lambda sn, org: (events.append((time.time(), {"type":"offline","sn":sn,"orgId":org})), dispatcher.submit({"type":"offline","sn":sn,"orgId":org}))
    handlers.on_online = lambda sn, org: (events.append((time.time(), {"type":"online","sn":sn,"orgId":org})), dispatcher.submit({"type":"online","sn":sn,"orgId":org}))

    @app.on_event("startup")
    async def _startup():
        await dispatcher.start()
        start_mqtt_listener(handlers)
        return

    @app.on_event("shutdown")
    async def _shutdown():
        await dispatcher.stop()
        await http.close()

    @app.get("/health")
    async def health():
        return {"ok": True}

    @app.get("/events")
    async def get_events(limit: int = Query(50, ge=1, le=500), _=Depends(require_key)):
        out = list(events)[-limit:]
        return [{"ts": ts, "msg": msg} for ts, msg in out]

    @app.get("/sensors")
    async def sensors(_=Depends(require_key), pageNo: int = 1, pageSize: int = 20, sn: str | None = None, model: int | None = None, unitId: int | None = None):
        return await sysapi.get_sensors(pageNo=pageNo, pageSize=pageSize, sn=sn, model=model, unitId=unitId)

    @app.get("/sensors/{sn}")
    async def sensor(sn: str, _=Depends(require_key)):
        return await sysapi.get_sensor(sn)

    @app.put("/sensors/{sn}/scanarea")
    async def scanarea(_=Depends(require_key), sn: str, left: int, right: int, height: int):
        return await sysapi.set_scan_area(sn, left, right, height)

    @app.put("/sensors/{sn}/fall")
    async def fall(_=Depends(require_key), sn: str, threshold: int):
        return await sysapi.set_fall_threshold(sn, threshold)

    @app.put("/sensors/{sn}/actions/location/start")
    async def loc_start(_=Depends(require_key), sn: str):
        return await sysapi.start_location_stream(sn)

    @app.put("/sensors/{sn}/actions/location/stop")
    async def loc_stop(_=Depends(require_key), sn: str):
        return await sysapi.stop_location_stream(sn)

    @app.get("/firmware")
    async def firmware(_=Depends(require_key)):
        return await sysapi.list_upgradeable_firmware()

    return app

def app():
    return create_app()