from __future__ import annotations
import json
import threading
import paho.mqtt.client as mqtt
from .config import MQTT, build_ssl_context
from .event_router import route_event, Handlers

def start_mqtt_listener(handlers: Handlers) -> mqtt.Client:
    ssl_ctx = build_ssl_context(MQTT)
    client = mqtt.Client(client_id=MQTT.client_id, protocol=mqtt.MQTTv5)
    client.tls_set_context(ssl_ctx)

    topic = f"/client/{MQTT.client_id}"

    def _on_connect(_c, _u, _f, rc, _p=None):
        if rc == mqtt.MQTT_ERR_SUCCESS:
            _c.subscribe(topic, qos=1)
            print(f"[MQTT] connected; subscribed to {topic}")
        else:
            print(f"[MQTT] connect failed rc={rc}")

    def _on_message(_c, _u, msg: mqtt.MQTTMessage):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
        except Exception as e:
            print(f"[MQTT] bad JSON: {e}")
            return
        route_event(payload, handlers)

    client.on_connect = _on_connect
    client.on_message = _on_message
    client.connect(MQTT.host, MQTT.port, keepalive=60)

    t = threading.Thread(target=client.loop_forever, name="mqtt-loop", daemon=True)
    t.start()
    return client