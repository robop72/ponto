from __future__ import annotations
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict

class Target(BaseModel):
    id: int = Field(ge=1, le=255)
    x: int = Field(ge=0, le=600)
    y: int = Field(ge=0, le=600)
    z: int = Field(ge=0, le=200)

class Presence(BaseModel):
    bedin: Optional[List[Target]] = None
    couchin: Optional[List[Target]] = None
    pfall: Optional[List[Target]] = None
    fall: Optional[List[Target]] = None
    other: Optional[List[Target]] = None

class EventParams(BaseModel):
    sn: str
    orgId: int
    online: Optional[Dict] = None
    presence: Optional[Presence] = None
    radar: Optional[Dict] = None
    angle: Optional[Dict] = None
    wifi: Optional[Dict] = None
    upgrade: Optional[Dict] = None

class EventReport(BaseModel):
    method: str
    params: EventParams
    model_config = ConfigDict(extra="allow")

class LwtParams(BaseModel):
    sn: str
    orgId: int

class LwtReport(BaseModel):
    method: str
    params: LwtParams