from __future__ import annotations

from .http_client import PsHttp

class SystemApi:
    def __init__(self, http: PsHttp):
        self.http = http

    async def list_upgradeable_firmware(self) -> list[dict]:
        res = await self.http.get("/firmware")
        res.raise_for_status()
        return res.json()

    async def get_sensors(self, **params) -> dict:
        res = await self.http.get("/sensors", params=params)
        res.raise_for_status()
        return res.json()

    async def get_sensor(self, sn: str) -> dict:
        res = await self.http.get(f"/sensors/{sn}")
        res.raise_for_status()
        return res.json()

    async def delete_sensor(self, sn: str) -> dict:
        res = await self.http.delete(f"/sensors/{sn}")
        res.raise_for_status()
        return res.json()

    async def apply_mqtt_certs(self, sn: str, model: int, version: str) -> dict:
        res = await self.http.post(f"/sensors/{sn}/certs", json={"model": model, "version": version})
        res.raise_for_status()
        return res.json()

    async def upgrade_firmware(self, sn: str, firmware_id: int, ota_type: int = 0) -> dict:
        res = await self.http.put(f"/sensors/{sn}/actions/upgrade",
                                  json={"firmwareId": firmware_id, "otaType": ota_type})
        res.raise_for_status()
        return res.json()

    async def set_zones(self, sn: str, zones: list[dict]) -> dict:
        res = await self.http.put(f"/sensors/{sn}/zones", json=zones)
        res.raise_for_status()
        return res.json()

    async def set_scan_area(self, sn: str, left: int, right: int, height: int) -> dict:
        res = await self.http.put(f"/sensors/{sn}/scanarea", json={"left": left, "right": right, "height": height})
        res.raise_for_status()
        return res.json()

    async def set_fall_threshold(self, sn: str, threshold: int) -> dict:
        res = await self.http.put(f"/sensors/{sn}/fall", json={"threshold": threshold})
        res.raise_for_status()
        return res.json()

    async def start_location_stream(self, sn: str) -> dict:
        res = await self.http.put(f"/sensors/{sn}/actions/location/start")
        res.raise_for_status()
        return res.json()

    async def stop_location_stream(self, sn: str) -> dict:
        res = await self.http.put(f"/sensors/{sn}/actions/location/stop")
        res.raise_for_status()
        return res.json()

    async def get_units(self, **params) -> dict:
        res = await self.http.get("/units", params=params)
        res.raise_for_status()
        return res.json()

    async def bind_sensor_to_unit(self, sn: str, unit_id: int) -> dict:
        res = await self.http.put(f"/units/{unit_id}/sensors/{sn}")
        res.raise_for_status()
        return res.json()