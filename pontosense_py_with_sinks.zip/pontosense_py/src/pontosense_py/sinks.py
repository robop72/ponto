from __future__ import annotations
import asyncio, json, os
from typing import Optional, Any, Dict, List

import httpx
from aiokafka import AIOKafkaProducer

class EventDispatcher:
    """Fan-out events to optional sinks (webhook, Kafka). Thread-safe submit()."""
    def __init__(self):
        self.queue: asyncio.Queue[dict] = asyncio.Queue(maxsize=5000)
        self._tasks: List[asyncio.Task] = []
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        # Webhook
        self.webhook_url = os.getenv("WEBHOOK_URL") or ""
        self.webhook_secret = os.getenv("WEBHOOK_SECRET") or ""
        # Kafka
        self.kafka_bootstrap = os.getenv("KAFKA_BOOTSTRAP_SERVERS") or ""
        self.kafka_topic = os.getenv("KAFKA_TOPIC") or "pontosense.events"
        self.kafka_security_protocol = os.getenv("KAFKA_SECURITY_PROTOCOL") or "PLAINTEXT"
        self.kafka_sasl_mechanism = os.getenv("KAFKA_SASL_MECHANISM") or "PLAIN"
        self.kafka_username = os.getenv("KAFKA_SASL_USERNAME") or ""
        self.kafka_password = os.getenv("KAFKA_SASL_PASSWORD") or ""

        self._kafka: Optional[AIOKafkaProducer] = None
        self._http: Optional[httpx.AsyncClient] = None

    def submit(self, event: dict):
        # thread-safe enqueue
        if self._loop is None:
            return
        try:
            self._loop.call_soon_threadsafe(self.queue.put_nowait, event)
        except Exception:
            pass

    async def start(self):
        self._loop = asyncio.get_running_loop()
        self._http = httpx.AsyncClient(timeout=10.0)
        if self.kafka_bootstrap:
            conf = {
                "bootstrap_servers": self.kafka_bootstrap.split(","),
                "value_serializer": lambda v: json.dumps(v).encode("utf-8"),
            }
            if self.kafka_security_protocol != "PLAINTEXT":
                conf["security_protocol"] = self.kafka_security_protocol
            if self.kafka_username and self.kafka_password:
                conf["sasl_mechanism"] = self.kafka_sasl_mechanism
                conf["sasl_plain_username"] = self.kafka_username
                conf["sasl_plain_password"] = self.kafka_password
            self._kafka = AIOKafkaProducer(**conf)
            await self._kafka.start()

        # Workers
        self._tasks.append(asyncio.create_task(self._pump()))

    async def stop(self):
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        if self._kafka:
            await self._kafka.stop()
        if self._http:
            await self._http.aclose()

    async def _pump(self):
        while True:
            evt = await self.queue.get()
            await asyncio.gather(
                self._send_webhook(evt),
                self._send_kafka(evt),
                return_exceptions=True
            )

    async def _send_webhook(self, evt: dict):
        if not self.webhook_url or not self._http:
            return
        headers = {}
        if self.webhook_secret:
            headers["X-Webhook-Secret"] = self.webhook_secret
        try:
            await self._http.post(self.webhook_url, json=evt, headers=headers)
        except Exception:
            pass

    async def _send_kafka(self, evt: dict):
        if not self._kafka:
            return
        try:
            await self._kafka.send_and_wait(self.kafka_topic, value=evt)
        except Exception:
            pass