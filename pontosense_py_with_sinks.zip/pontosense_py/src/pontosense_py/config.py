from __future__ import annotations
import os, ssl, pathlib
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

def _env(name: str, required: bool = True, default: str | None = None) -> str | None:
    v = os.getenv(name, default)
    if required and not v:
        raise RuntimeError(f"Missing environment variable: {name}")
    return v

def _read_pem(path_env: str, pem_env: str) -> bytes | None:
    pem = os.getenv(pem_env)
    if pem:
        return pem.encode("utf-8")
    p = os.getenv(path_env)
    if p:
        return pathlib.Path(p).read_bytes()
    return None

@dataclass(frozen=True)
class HttpCfg:
    base_url: str
    access_key: str
    header_name: str

@dataclass(frozen=True)
class MqttCfg:
    host: str
    port: int
    client_id: str
    cert_pem: bytes | None
    key_pem: bytes | None
    ca_pem: bytes | None

def build_ssl_context(cfg: MqttCfg) -> ssl.SSLContext:
    ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH)
    if cfg.ca_pem:
        ctx.load_verify_locations(cadata=cfg.ca_pem.decode("utf-8"))
    if not (cfg.cert_pem and cfg.key_pem):
        raise RuntimeError("Client certificate and private key are required for MQTT TLS.")
    import tempfile
    cert_tmp = tempfile.NamedTemporaryFile(delete=False)
    key_tmp = tempfile.NamedTemporaryFile(delete=False)
    cert_tmp.write(cfg.cert_pem); cert_tmp.flush()
    key_tmp.write(cfg.key_pem); key_tmp.flush()
    ctx.load_cert_chain(certfile=cert_tmp.name, keyfile=key_tmp.name)
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED
    return ctx

HTTP = HttpCfg(
    base_url=_env("PONTOSENSE_HTTP_BASE"),
    access_key=_env("PONTOSENSE_ACCESS_KEY"),
    header_name=os.getenv("PONTOSENSE_HTTP_HEADER_NAME", "Access-Key"),
)

MQTT = MqttCfg(
    host=_env("PONTOSENSE_MQTT_HOST"),
    port=int(os.getenv("PONTOSENSE_MQTT_PORT", "8883")),
    client_id=_env("PONTOSENSE_CLIENT_ID"),
    cert_pem=_read_pem("PONTOSENSE_TLS_CERT_PATH", "PONTOSENSE_TLS_CERT_PEM"),
    key_pem=_read_pem("PONTOSENSE_TLS_KEY_PATH", "PONTOSENSE_TLS_KEY_PEM"),
    ca_pem=_read_pem("PONTOSENSE_TLS_CA_PATH", "PONTOSENSE_TLS_CA_PEM"),
)